﻿using $ext_safeprojectname$.Interfaces.$ext_ServiceModule$;

namespace $ext_safeprojectname$.Services.$ext_ServiceModule$
{
	public class $ext_ServiceModule$Module : I$ext_ServiceModule$Module
	{
	}
}
