﻿using Relativity.Kepler.Services;

namespace $rootnamespace$
{
	public class $safeitemrootname$ : I$safeitemrootname$
	{ }
}