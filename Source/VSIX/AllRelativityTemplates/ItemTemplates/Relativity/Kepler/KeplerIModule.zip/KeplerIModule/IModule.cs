﻿using Relativity.Kepler.Services;

namespace $rootnamespace$
{
	[ServiceModule("$ServiceModule$ Module")]
	[RoutePrefix("$ServiceModule$", VersioningStrategy.Namespace)]
	public interface $safeitemrootname$
	{
	}
}